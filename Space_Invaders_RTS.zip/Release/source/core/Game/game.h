#pragma once

//In Gnereate.cpp

extern void initGame();

//In AI.cpp

//Run the ai
extern void ai_Run(float updateTime = 2.0f);