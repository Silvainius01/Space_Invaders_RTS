#include "../ui/input.h"
#include "../ui/ui.h"
#include <fstream>
#include <iostream>
#include <cstring>
using namespace std;
					//Mr. Clutchy
					//Silvainius
					//CrimsonRogue
char *profileName =	 "Silvainius";
unsigned playerColor = clr_BLUE;

void saveProfile()
{
	
}