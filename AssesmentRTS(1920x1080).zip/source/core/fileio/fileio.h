#pragma once

extern unsigned playerColor;
extern char *profileName;

extern void saveProfile();